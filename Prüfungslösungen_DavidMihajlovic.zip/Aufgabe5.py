"""
Created on Tue Jan 26 2021

SEP HS21 Aufgabe 5

@author: David Mihajlovic
"""



