"""
Created on Tue Jan 26 2021

SEP HS21 Aufgabe 6

@author: David Mihajlovic
"""

# separat pdf